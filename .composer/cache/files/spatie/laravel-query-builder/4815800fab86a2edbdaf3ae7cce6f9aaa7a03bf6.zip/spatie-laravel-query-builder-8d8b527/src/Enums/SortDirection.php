<?php

namespace Spatie\QueryBuilder\Enums;

class SortDirection
{
    public const DESCENDING = 'desc';

    public const ASCENDING = 'asc';
}
